# 🏂 Snow Boarder – Cuộc Phiêu Lưu Trên Núi Tuyết

Một game thể thao arcade được phát triển bằng **Unity 2025 (Unity 6.x)** – phiên bản mới nhất với hiệu suất cao, hỗ trợ đa nền tảng và tích hợp vật lý chân thực. Người chơi điều khiển vận động viên trượt tuyết vượt qua các sườn núi hiểm trở, né tránh chướng ngại vật và thực hiện các pha biểu diễn để ghi điểm.

---

## 🎮 Gameplay

**Điều khiển:**
- Dùng phím mũi tên hoặc WASD để rẽ trái/phải.
- Tăng/giảm tốc độ bằng các phím điều hướng hoặc trigger tùy chỉnh.

**Mục tiêu:**
- Trượt xuống núi tuyết, vượt qua các đoạn đường nguy hiểm.
- Thực hiện trick thu nhập nhẫn vàng và ghi được điểm cao.

**Giao diện:**
- **SCORE**: Hiển thị điểm số hiện tại.
- **TIME**: Thời gian hiện tại

---

## 🛠️ Công nghệ sử dụng

- **Unity 2025 (Unity 6.x)** – tối ưu hóa hiệu suất, hỗ trợ đa nền tảng (PC, mobile, console, XR)
- **C# Scripts** – điều khiển hành vi nhân vật, vật lý và hệ thống điểm
- **2D Sprites & UI Canvas** – thiết kế giao diện và đồ họa
- **Unity Physics Engine** – mô phỏng lực ma sát, trọng lực, độ nghiêng sườn núi
- **Git** – quản lý phiên bản và cộng tác nhóm

---

## 📦 Cài đặt & Chạy game

1. Clone repo:
   ```bash
   git clone https://github.com/quoccc86/SnowBoarder1.git
2. Mở project bằng Unity 2025.

3. Vào File > Build Settings, chọn Windows và nhấn Build.

4. Chạy file .exe trong thư mục build.

5.Deployment
```bash
https://quoccc86.github.io/snowboarder-webgl2/
